import type { User } from "@prisma/client";

import type { LoginDto } from "../dto/login.dto";
import type { RegisterDto } from "../dto/register.dto";

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface AuthResult {
  user: User;
  tokens: AuthTokens;
}

export interface RefreshTokenResult {
  accessToken: string;
  refreshToken: string;
}

export interface IAuthService {
  /**
   * Register a new user.
   */
  register(dto: RegisterDto): Promise<AuthResult>;

  /**
   * Login an existing user.
   */
  login(dto: LoginDto): Promise<AuthResult>;

  /**
   * Refresh the user's access and refresh tokens.
   */
  refreshToken(refreshToken: string): Promise<RefreshTokenResult>;

  /**
   * Logout from the current device.
   */
  logout(refreshToken: string): Promise<void>;

  /**
   * Logout from all devices.
   */
  logoutAll(userId: string): Promise<void>;
}
