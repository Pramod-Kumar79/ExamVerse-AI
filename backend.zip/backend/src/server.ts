import dotenv from "dotenv";
import app from "./app";

import "./lib/prisma";
dotenv.config();

const PORT = process.env.PORT || 5000;

import { env } from "./config/env";
import { logger } from "./lib/logger";

app.listen(PORT, () => {
  console.log("");
  console.log("====================================");
  console.log("🚀 ExamVerse AI Backend Started");
  console.log(`🌐 http://localhost:${PORT}`);
  console.log("====================================");
  console.log("");
});
